

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;  
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;  
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.ExpressionStatement;  
import org.eclipse.jdt.core.dom.IfStatement;  
import org.eclipse.jdt.core.dom.InfixExpression;  
import org.eclipse.jdt.core.dom.InfixExpression.Operator;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.rewrite.ASTRewrite;
import org.eclipse.jdt.core.dom.rewrite.ListRewrite;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.Document;
import org.eclipse.text.edits.MalformedTreeException;
import org.eclipse.text.edits.TextEdit;
import org.eclipse.jdt.core.dom.MethodInvocation;  
import org.eclipse.jdt.core.dom.QualifiedName;  
import org.eclipse.jdt.core.dom.SimpleName;  
import org.eclipse.jdt.core.dom.StringLiteral;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.WhileStatement;  
  
public class WhileTransformer extends ASTVisitor { 
	int count ;
	int whileNumber;
	int whilechoose;
	@Override  
    public boolean visit(TypeDeclaration md) {
		count = 0;
		//System.out.println(count);
		//System.out.println(whileNumber);
		return true;
	}
	 public void endVisit(TypeDeclaration md) {
			//System.out.println(count);
			
		}
    @Override  
    public boolean visit(WhileStatement node) {  
    	count++;
    	//System.out.println("Current count = "+count);
    	//System.out.println("Current whilechoose = "+whilechoose);
    	if(count==whilechoose){
    		
    		InfixExpression ie = (InfixExpression)node.getExpression(); 
    		//System.out.println(ie);
    		String o = ie.getOperator().toString();
    		if(o.equals(">")||o.equals("<")||o.equals(">=")||o.equals("<=")||o.equals("==")){
    			ie.setOperator(Operator.NOT_EQUALS);
    		}
    		if(o.equals("!=")){
    			ie.setOperator(Operator.EQUALS);
    		}
    		//System.out.println(ie);
    	}
        
     //  
         
        
    	
			

            return false; 
    }  
}  