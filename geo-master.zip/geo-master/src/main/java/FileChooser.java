  
import java.awt.event.ActionEvent;  
import java.awt.event.ActionListener;  
import java.io.File;  
  
import javax.swing.JButton;  
import javax.swing.JFileChooser;  
import javax.swing.JFrame;  
import javax.swing.JLabel;
import javax.swing.JOptionPane;  
  
public class FileChooser {  
	String Opath = null;
	public FileChooser(){  
		JFileChooser jfc=new JFileChooser();  
        jfc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES );  
        jfc.showDialog(new JLabel(), "select");  
        File file=jfc.getSelectedFile();  
        if(file.isFile()){  
            CopyFile newfolder = new CopyFile();
            Opath = file.getAbsolutePath();
            newfolder.initializeDataStore();
            newfolder.copyfiles(Opath);
        }  
        else{
        	
        	JOptionPane.showMessageDialog(null, "Please choose a java file");   
        	return;

        }
        
        //System.out.println(jfc.getSelectedFile().getName());   
    }  
}  

  