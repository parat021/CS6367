import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.WhileStatement;

public class CountStatements extends ASTVisitor {
	int countWhile, countIF, countReturn, CountExpression;
	String str;
	List<Object> recordAll = new ArrayList<Object>();

	public List<Object> collect() {
		return recordAll;// countWhile,countIF,countReturn,CountExpression

	}

	@Override
	public boolean visit(TypeDeclaration md) {
		str = md.getName().toString();
		// System.out.println(str);
		// System.out.println(recordAll)
		if (str.equals("GeoHash")) {

			recordAll.clear();
			countWhile = 0;
			countIF = 0;
			countReturn = 0;
			CountExpression = 0;
			return true;
		}

		return false;
	}

	public void endVisit(TypeDeclaration md) {
		str = md.getName().toString();
		if (str.equals("GeoHash")) {
			recordAll.add(countWhile);
			recordAll.add(countIF);
			recordAll.add(countReturn);
			recordAll.add(CountExpression);
			// System.out.println(recordAll);
			collect();
		}

		// System.out.println("1");
		// System.out.println(recordAll);
	}

	@Override
	public boolean visit(WhileStatement node) {
		if (str.equals("GeoHash")) {
			countWhile++;
		}

		return false;
	}

	public boolean visit(IfStatement node) {
		if (str.equals("GeoHash")) {
			countIF++;
		}

		return false;
	}

	public boolean visit(ReturnStatement node) {
		if (str.equals("GeoHash")) {
			countReturn++;
		}

		return false;
	}

	public boolean visit(ExpressionStatement node) {

		if (str.equals("GeoHash")) {
			CountExpression++;
		}

		return false;
	}

}
