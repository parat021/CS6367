import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.InfixExpression;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.WhileStatement;
import org.eclipse.jdt.core.dom.InfixExpression.Operator;

public class IfTransformer extends ASTVisitor {
	int count;
	int ifNumber;
	int ifchoose;
	String str;

	public boolean visit(TypeDeclaration md) {
		str = md.getName().toString();
		// System.out.println(ifNumber);
		if (str.equals("GeoHash")) {
			count = 0;
			return true;
		}
		return false;
	}

	public boolean visit(IfStatement node) {
		if (str.equals("GeoHash")) {

			count++;

			if (count == ifchoose) {
			//	System.out.println(count);

				InfixExpression ie = null;

				
				String cp = node.getExpression().toString();
				//System.out.println(cp);
				if (cp.indexOf(">") > 0 || cp.indexOf("<") >0 || cp.indexOf(">=") > 0 || cp.indexOf("<=") > 0
						|| cp.indexOf("==")> 0 || cp.indexOf("!=") > 0) {
					ie = (InfixExpression) node.getExpression();
					String o = null;
					o = ie.getOperator().toString();

					if (o.equals(">") || o.equals("<") || o.equals(">=") || o.equals("<=") || o.equals("==")) {
						ie.setOperator(Operator.NOT_EQUALS);
					}
					if (o.equals("!=")) {
						ie.setOperator(Operator.EQUALS);
					}
					if (o.equals("||") || o.equals("&&")) {
						ie.setOperator(Operator.EQUALS);
					}
				//	System.out.println(node.getExpression().toString());
				}

			}

			// System.out.println(ie);

			// System.out.println(ie);

		}

		return false;
	}
}
