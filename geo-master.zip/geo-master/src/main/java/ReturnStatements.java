import javax.lang.model.element.VariableElement;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.BooleanLiteral;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.FieldAccess;
import org.eclipse.jdt.core.dom.InfixExpression;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclaration;
import org.eclipse.jdt.core.dom.WhileStatement;
import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
import org.eclipse.jdt.core.dom.InfixExpression.Operator;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.PrimitiveType;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.StringLiteral;

public class ReturnStatements extends ASTVisitor {
	int count;
	int returnNumber;
	int returnchoose;
	String methodType, str;

	public boolean visit(TypeDeclaration md) {
		str = md.getName().toString();
		// System.out.println(str);
		// System.out.println(recordAll)
		if (str.equals("GeoHash")) {
			count = 0;
			return true;
		}

		return false;
	}

	public boolean visit(MethodDeclaration node) {
		if (str.equals("GeoHash")) {
			// System.out.println(node.getReturnType2().toString());

			if (node.getReturnType2() == null) {
				return false;
			} else {
				methodType = node.getReturnType2().toString().toLowerCase();
				//System.out.println(methodType);
				return true;
			}

		}

		return false;

	}

	public boolean visit(ReturnStatement node) {
		if (str.equals("GeoHash")) {
			count++;
			if (count == returnchoose) {
				
				if (methodType.equals("int") || methodType.equals("double") || methodType.equals("float")
						|| methodType.equals("long")) {

					Expression e = node.getExpression();
					AST ast = e.getAST();
					String Stringe = e.toString();
					SimpleName nameMath = ast.newSimpleName("Math");
					SimpleName nameABS = ast.newSimpleName("abs");
					MethodInvocation methodInv = ast.newMethodInvocation();
					methodInv.setExpression(nameMath);
					methodInv.setName(nameABS);

					methodInv.arguments().add(ast.newSimpleName(Stringe));

					node.setExpression(methodInv);
					// node.getExpression();
					// node.setExpression();*/
					//System.out.println(node.getExpression());

					// SimpleName snMath =node.newSimpleName("Math");
					// SimpleName snABS;
				}
				if (methodType.equals("boolean")) {
					Expression e = node.getExpression();
					AST ast = e.getAST();
					String Stringe = e.toString().toLowerCase();
					if (Stringe.equals("true")) {
						BooleanLiteral b = ast.newBooleanLiteral(false);
						node.setExpression(b);
					}
					if (Stringe.equals("false")) {
						BooleanLiteral b = ast.newBooleanLiteral(true);
						node.setExpression(b);
					}
				}
			}
		}

		return false;
	}
}
