import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

public class CopyFile {
	
	
	 public  void initializeDataStore(){
		 try {
				File dataDir = new File("../temp");//创建一个抽象文件夹 
				 
				dataDir.mkdir();//建立文件夹
				String[] oldTableFiles;
				oldTableFiles = dataDir.list();
				//循环清空data下所有文件
				for (int i=0; i<oldTableFiles.length; i++) {
					File anOldFile = new File(dataDir, oldTableFiles[i]); 
					anOldFile.delete();
				}
			}
			catch (SecurityException se) {
				System.out.println("Unable to create data container directory");
				System.out.println(se);
			}
	 }
	 public void copyfiles(String path){
		 File source = new File(path);
		 File dest = new File("../temp");
		 try {
		     FileUtils.copyFileToDirectory(source, dest);
		 } catch (IOException e) {
		     e.printStackTrace();
		 }
	 }
}
