import java.io.File;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.rewrite.ASTRewrite;
import org.eclipse.jdt.core.dom.rewrite.ListRewrite;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.Document;
import org.eclipse.text.edits.MalformedTreeException;
import org.eclipse.text.edits.TextEdit;
import org.junit.rules.Timeout;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import com.github.davidmoten.geo.GeoHashTest;


public class DemoVisitorTest2 {
	WhileTransformer visitor;
	IfTransformer visitorIF;
	ReturnStatements  visitorReturn;
	 CountStatements visitorN;
	 List<Object> recordAll;
	static List<Object> recordFile;
	 CompilationUnit cu;
	 CompilationUnit temp;
	 Document document;
	 ASTParser parser2;
	  static int killedMutant;
	public DemoVisitorTest2(String path) throws IOException, MalformedTreeException, BadLocationException{ 
		killedMutant = 0;
		 visitor = new WhileTransformer();
		 visitorN = new CountStatements();
		 visitorIF = new IfTransformer();
		 visitorReturn = new ReturnStatements();
		 String source = FileUtils.readFileToString(new File(path),"UTF-8");
		 document = new Document(source);
		
		
		 ASTParser parser = ASTParser.newParser(AST.JLS3);
		 parser.setSource(document.get().toCharArray());
		 parser.setKind(ASTParser.K_COMPILATION_UNIT);
		 
		 ASTParser parser2 = ASTParser.newParser(AST.JLS3);
		 parser2.setSource(document.get().toCharArray());
		 parser2.setKind(ASTParser.K_COMPILATION_UNIT);
		 
		 cu = (CompilationUnit) parser.createAST(null);
		// temp = (CompilationUnit)parser2.createAST(null);
		    
		 recordAll = new ArrayList<Object>(); //countWhile,countIF,countReturn,CountExpression
		// System.out.println(recordAll);
		 cu.accept(visitorN);
		 cu.recordModifications();
		 //System.out.println(temp);
		//  cu.recordModifications();
		  
		 
		//ListRewrite lrw = rewriter.getListRewrite(WhileStatement, CompilationUnit.);
		 //TextEdit edits = rewriter.rewriteAST(document,null);
		 //edits.apply(document);
		 
		// Document D2 = new Document(cu.toString());
		// System.out.println(document.get());
		// FileUtils.write(new File(path),D2.get(),"UTF-8");
    
    }  
	public void whileMutant() throws IOException{
		
		
		 visitor.whileNumber = (int)recordAll.get(0);//countWhile,countIF,countReturn,CountExpression
		// cu.recordModifications();
		//System.out.println(visitor.whileNumber);
		 for(int i = 1;i<= visitor.whileNumber;i++){
			 visitor.whilechoose = i;
			
			 cu.accept(visitor);
			// System.out.println("Modified cu = "+cu);
			 Document D2 = new Document(cu.toString());
			 String path = "../tempMutant/";
			 path = path+"While"+i+".java";
			 recordFile.add(path);
			 FileUtils.write(new File(path),D2.get(),"UTF-8");
			 
			 ASTParser parser2 = ASTParser.newParser(AST.JLS3);
			 parser2.setSource(document.get().toCharArray());
			 parser2.setKind(ASTParser.K_COMPILATION_UNIT);
			 temp = (CompilationUnit)parser2.createAST(null);
			 cu = temp;
			 //System.out.println("Oringinal temp= "+temp);
			// System.out.println("Oringinal cu = "+cu);
			 
			
		 }
	}
		 public void ifMutant() throws IOException{
			 
			 visitorIF.ifNumber = (int)recordAll.get(1);//countWhile,countIF,countReturn,CountExpression
			// cu.recordModifications();
			//System.out.println(visitor.whileNumber);
			 for(int i = 1;i<= visitorIF.ifNumber;i++){
				 visitorIF.ifchoose = i;
				
				 cu.accept(visitorIF);
				// System.out.println("Modified cu = "+cu);
				  
				 Document D2 = new Document(cu.toString());
				 String path = "../tempMutant/";
				 path = path+"If"+i+".java";
				 recordFile.add(path);
				 FileUtils.write(new File(path),D2.get(),"UTF-8");
				 
				 ASTParser parser2 = ASTParser.newParser(AST.JLS3);
				 parser2.setSource(document.get().toCharArray());
				 parser2.setKind(ASTParser.K_COMPILATION_UNIT);
				 temp = (CompilationUnit)parser2.createAST(null);
				 cu = temp;
				// System.out.println("Oringinal temp= "+temp);
				//System.out.println("Oringinal cu = "+cu);
				 
				
			 }
		
	}
		 public void ReturnMutant() throws IOException{
			
			 visitorReturn.returnNumber = (int)recordAll.get(2);//countWhile,countIF,countReturn,CountExpression
			// cu.recordModifications();
			//System.out.println(visitor.whileNumber);
			 for(int i = 1;i<= visitorReturn.returnNumber;i++){
				 visitorReturn.returnchoose = i;
				
				 cu.accept(visitorReturn);
			//	 System.out.println("Modified cu = "+cu);
				  
				 Document D2 = new Document(cu.toString());
				 String path = "../tempMutant/";
				 path = path+"Return"+i+".java";
				 recordFile.add(path);
				 FileUtils.write(new File(path),D2.get(),"UTF-8");
				 
				 ASTParser parser2 = ASTParser.newParser(AST.JLS3);
				 parser2.setSource(document.get().toCharArray());
				 parser2.setKind(ASTParser.K_COMPILATION_UNIT);
				 temp = (CompilationUnit)parser2.createAST(null);
				 cu = temp;
				 //System.out.println("Oringinal temp= "+temp);
				// System.out.println("Oringinal cu = "+cu);
				 
				
			 }
		
	}
		public void countNumber(){
			recordAll.clear();
			recordAll.addAll(visitorN.collect());
			//System.out.println(recordAll);
		}
		public  void createDocument(){
			 try {
				 recordFile = new ArrayList<Object>();
					File dataDir = new File("../tempMutant");//创建一个抽象文件夹 
					 
					dataDir.mkdir();//create document
					String[] oldTableFiles;
					oldTableFiles = dataDir.list();
					//
					for (int i=0; i<oldTableFiles.length; i++) {
						File anOldFile = new File(dataDir, oldTableFiles[i]); 
						anOldFile.delete();
					}
				}
				catch (SecurityException se) {
					System.out.println("Unable to create data container directory");
					System.out.println(se);
				}
		 }
		public static void ToOringinal (String src, String dst) throws IOException{
			FileUtils.copyFile(new File(src),new File(dst));
			//testScore();
		}
		public  static void testScore(){
			
			JUnitCore junit = new JUnitCore();
			Result result = junit.run(GeoHashTest.class);
			
			if(result.getFailureCount()>0){
				
				killedMutant = killedMutant+1;
			}
		//	System.out.println("killedMutant = "+killedMutant);
		/*	 for (Failure failure : result.getFailures()) {
		         System.out.println(failure.toString());
		      }*/
			//System.out.println("score = "+score);
			
			
			
			
			
			
			
		}
		public static void restoreFile(String dst) throws IOException{
			String src;
			src ="../temp/GeoHash.java";		
			FileUtils.copyFile(new File(src),new File(dst));
		}
	public static void main(String[] args) throws IOException, MalformedTreeException, BadLocationException{
		
		String originPath;
		FileChooser a = new FileChooser();
		originPath = a.Opath;
		//System.out.println(originPath);
		if(originPath==null){
			return;
		}

		
		DemoVisitorTest2 test = new DemoVisitorTest2(originPath);
		test.createDocument();
		test.countNumber();
		test.whileMutant();
		
		test.ifMutant();
		test.ReturnMutant();
		
		for(int i =0;i<test.recordFile.size();i++){
			String mutantPath;
			
			mutantPath = test.recordFile.get(i).toString();
			//System.out.println(recordFile.get(i));
			ToOringinal (mutantPath, originPath);
			
			test.testScore();
			restoreFile(originPath);
			
		}
		//test.testScore();
		
		
		
		double showscore;
		System.out.println("Killed mutants =  "+killedMutant);
		System.out.println("Total mutants = "+test.recordFile.size());
		showscore = killedMutant/test.recordFile.size();
		NumberFormat percentFormat =java.text.NumberFormat.getPercentInstance(); 
		System.out.println("mutation score is "+ percentFormat.format(showscore));
		
		
	}

}
